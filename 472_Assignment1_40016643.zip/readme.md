https://github.com/ashkanM7/C472-MP1

T1: two .py files: -p1.1_plot.py reads the files and generates the distribution plot -p1.1_clf.py implements the Naive Bayes classifier.

T2: Seven .py files -p1.2_plot.py to generate the distribution -for the rest of the files, each file corresponds to the implementation of a specific method i.e GNB, base-dt, etc. these files also contain the caldulation of the average and std accuracy mac-ave-f1 and w-ave-f1.

To show the metrics: 1-comment out the section related to the average and std values at the bottom of the file. 2-Run the code

To find the averaeg and std values: 1-Run the code and record the values of average accuracy mac-ave-f1 and w-ave-f1 to the lists correspondin to them 2- Uncomment the lists, average and std calculators as well as the print sections corresonding to them and run the code